
1. A sample xsl has been provided.
2. Run it as follows : 
   
   xsltproc sample_transform.xsl vmware_xml_config.xml
   
3. The goal is come up with XSL Transforms for the rest of the questions.
   